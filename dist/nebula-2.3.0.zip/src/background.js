// Nébula — background service worker (MV3, ES module).
// Responsibilities:
//  * own the settings + the per-session seed
//  * resolve the one coherent "active profile"
//  * publish a runtime config that content scripts read
//  * keep HTTP headers (UA / Accept-Language / Sec-CH-UA) in sync via DNR

import { DEFAULT_SETTINGS, PRESETS, randomProfile, RANDOM_POOLS, TRAVEL_COUNTRIES } from './lib/profiles.js';
import { mulberry32, seedFrom } from './lib/rng.js';

const SETTINGS_KEY = 'nebula:settings';
const CONFIG_KEY = 'nebula:config'; // resolved runtime config read by content scripts
const SEED_KEY = 'nebula:sessionSeed';
const GEO_KEY = 'nebula:geo';
const GEO_TTL_MS = 60 * 60 * 1000; // re-check the IP's timezone at most hourly
const DNR_RULE_BASE = 1000;
const TRACKER_RULE_ID = 2000;
const URLCLEAN_RULE_ID = 3000;
const REFERER_RULE_ID = 3001;
const TPCOOKIES_RULE_ID = 3002;
const STATS_KEY = 'nebula:stats';
const FPLOG_KEY = 'nebula:fplog';
const BOOT_STATUS_KEY = 'nebula:bootStatus';
const BOOT_SCRIPT_ID = 'nebula-boot';

// Tracking query parameters stripped from URLs (exact names; the match regex is
// built from this same list so removal always changes the URL — no redirect loop).
const TRACKING_PARAMS = [
  'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id', 'utm_name',
  'utm_cid', 'utm_reader', 'utm_social', 'utm_brand', 'utm_source_platform',
  'gclid', 'gclsrc', 'dclid', 'fbclid', 'msclkid', 'mc_eid', 'mc_cid', 'igshid', 'twclid',
  'yclid', 'mkt_tok', '_openstat', 'wickedid', 'vero_id', 'oly_anon_id', 'oly_enc_id',
  'hsa_cam', 'hsa_grp', 'hsa_ad', 'hsa_src', 'hsa_tgt', 'hsa_kw', 'hsa_mt', 'hsa_net', 'hsa_ver'
];

// Curated list of common analytics / advertising / session-replay trackers.
const TRACKER_DOMAINS = [
  'google-analytics.com', 'analytics.google.com', 'googletagmanager.com', 'googleadservices.com',
  'doubleclick.net', 'googlesyndication.com', 'adservice.google.com', 'pagead2.googlesyndication.com',
  'connect.facebook.net', 'graph.facebook.com', 'scorecardresearch.com',
  'quantserve.com', 'quantcount.com', 'adnxs.com', 'criteo.com', 'criteo.net', 'rubiconproject.com',
  'pubmatic.com', 'openx.net', 'taboola.com', 'outbrain.com', 'hotjar.com', 'static.hotjar.com',
  'mixpanel.com', 'api.mixpanel.com', 'segment.com', 'cdn.segment.com', 'amplitude.com',
  'api.amplitude.com', 'fullstory.com', 'mouseflow.com', 'clarity.ms', 'bat.bing.com',
  'ads.linkedin.com', 'px.ads.linkedin.com', 'analytics.twitter.com', 'ads-twitter.com',
  'snap.licdn.com', 'cdn.branch.io', 'app.link', 'bugsnag.com', 'nr-data.net', 'newrelic.com',
  'sentry.io', 'matomo.cloud', 'plausible.io', 'chartbeat.com', 'crazyegg.com', 'optimizely.com',
  'mc.yandex.ru', 'adroll.com', 'bluekai.com', 'demdex.net', 'omtrdc.net',
  'everesttech.net', 'moatads.com', 'adsrvr.org', 'casalemedia.com', 'sharethrough.com'
];
const TRACKER_SET = new Set(TRACKER_DOMAINS);

function hostIsTracker(host) {
  if (!host) return false;
  const parts = host.split('.');
  for (let i = 0; i < parts.length - 1; i++) {
    if (TRACKER_SET.has(parts.slice(i).join('.'))) return true;
  }
  return false;
}

// Live per-tab counter of tracker requests seen (real stat for the popup).
const tabTrackers = Object.create(null);
// Pending persistent-stats buffer (flushed to storage periodically / on demand).
let statsPending = 0;
const statsTopPending = Object.create(null);

function regDomain(host) {
  const parts = host.split('.');
  return parts.length <= 2 ? host : parts.slice(-2).join('.');
}
function todayKey() { return new Date().toISOString().slice(0, 10); }

async function flushStats() {
  if (statsPending === 0) return;
  const n = statsPending; statsPending = 0;
  const top = statsTopPending; for (const k in statsTopPending) delete statsTopPending[k];
  const cur = (await chrome.storage.local.get(STATS_KEY))[STATS_KEY] || { total: 0, days: {}, top: {} };
  cur.total = (cur.total || 0) + n;
  const day = todayKey();
  cur.days[day] = (cur.days[day] || 0) + n;
  // keep only the last 30 days
  const keys = Object.keys(cur.days).sort();
  while (keys.length > 30) delete cur.days[keys.shift()];
  for (const d in top) cur.top[d] = (cur.top[d] || 0) + top[d];
  // keep only the top 40 domains
  const entries = Object.entries(cur.top).sort((a, b) => b[1] - a[1]).slice(0, 40);
  cur.top = Object.fromEntries(entries);
  await chrome.storage.local.set({ [STATS_KEY]: cur });
}

try {
  chrome.webRequest.onBeforeRequest.addListener((d) => {
    if (d.tabId < 0) return;
    let host;
    try { host = new URL(d.url).hostname; } catch { return; }
    if (hostIsTracker(host)) {
      tabTrackers[d.tabId] = (tabTrackers[d.tabId] || 0) + 1;
      setBadge(d.tabId);
      statsPending++;
      const rd = regDomain(host);
      statsTopPending[rd] = (statsTopPending[rd] || 0) + 1;
      if (statsPending >= 10) flushStats();
    }
  }, { urls: ['<all_urls>'] });
} catch {}

// Record a fingerprinting attempt reported by a page (which site read canvas/etc).
async function recordFp(host, kind) {
  try {
    const data = (await chrome.storage.local.get(FPLOG_KEY))[FPLOG_KEY] || {};
    const e = data[host] || {};
    e[kind] = (e[kind] || 0) + 1;
    e._ts = Date.now();
    data[host] = e;
    const hosts = Object.entries(data).sort((a, b) => (b[1]._ts || 0) - (a[1]._ts || 0));
    if (hosts.length > 60) for (const [h] of hosts.slice(60)) delete data[h];
    await chrome.storage.local.set({ [FPLOG_KEY]: data });
  } catch {}
}

try {
  chrome.alarms.create('nebula-flush', { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a.name === 'nebula-flush') flushStats();
    else if (a.name === 'nebula-rotate') regenerateSeed();
  });
} catch {}

// Keep the auto-rotation alarm in sync with the setting.
async function syncRotateAlarm() {
  try {
    await chrome.alarms.clear('nebula-rotate');
    const settings = await getSettings();
    const m = Number(settings.autoRotateMin) || 0;
    if (m > 0) chrome.alarms.create('nebula-rotate', { periodInMinutes: m, delayInMinutes: m });
  } catch {}
}

try {
  chrome.webNavigation.onCommitted.addListener((d) => {
    if (d.frameId === 0) { tabTrackers[d.tabId] = 0; setBadge(d.tabId); }
  });
} catch {}

try {
  chrome.tabs.onRemoved.addListener((tabId) => { delete tabTrackers[tabId]; });
} catch {}

// ---- settings --------------------------------------------------------------

async function getSettings() {
  const got = await chrome.storage.local.get(SETTINGS_KEY);
  const stored = got[SETTINGS_KEY] || {};
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  // Deep-merge nested objects so new keys (e.g. added protections) default on.
  merged.protections = { ...DEFAULT_SETTINGS.protections, ...(stored.protections || {}) };
  merged.cleanData = { ...DEFAULT_SETTINGS.cleanData, ...(stored.cleanData || {}) };
  merged.ai = { ...DEFAULT_SETTINGS.ai, ...(stored.ai || {}) };
  return merged;
}

async function setSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  if (patch.protections) next.protections = { ...cur.protections, ...patch.protections };
  if (patch.cleanData) next.cleanData = { ...cur.cleanData, ...patch.cleanData };
  if (patch.ai) next.ai = { ...cur.ai, ...patch.ai };
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  await rebuild();
  return next;
}

// ---- session seed ----------------------------------------------------------

async function getSeed() {
  let got;
  try {
    got = await chrome.storage.session.get(SEED_KEY);
  } catch {
    got = await chrome.storage.local.get(SEED_KEY);
  }
  let seed = got[SEED_KEY];
  if (typeof seed !== 'number') {
    seed = (Math.random() * 0xffffffff) >>> 0;
    await saveSeed(seed);
  }
  return seed;
}

async function saveSeed(seed) {
  try {
    await chrome.storage.session.set({ [SEED_KEY]: seed });
  } catch {
    await chrome.storage.local.set({ [SEED_KEY]: seed });
  }
}

async function regenerateSeed() {
  const seed = (Math.random() * 0xffffffff) >>> 0;
  await saveSeed(seed);
  await rebuild();
  return seed;
}

// Wipe browsing state so a fresh identity is not linkable to the old one via
// cookies / site storage / cache. Leaves history, passwords and downloads alone.
async function clearBrowsingState(opts) {
  opts = opts || { cookies: true, storage: true, cache: true };
  const types = {};
  if (opts.cookies) types.cookies = true;
  if (opts.storage) {
    types.localStorage = true;
    types.indexedDB = true;
    types.cacheStorage = true;
    types.serviceWorkers = true;
    types.webSQL = true;
    types.fileSystems = true;
  }
  if (opts.cache) types.cache = true;
  if (!Object.keys(types).length) return false;
  try {
    await chrome.browsingData.remove({ since: 0 }, types);
    return true;
  } catch (e) {
    return false;
  }
}

// ---- profile resolution ----------------------------------------------------

function resolveProfile(settings, seed) {
  switch (settings.mode) {
    case 'blend':
      return structuredClone(PRESETS[settings.preset] || PRESETS['win-chrome']);
    case 'custom':
      return settings.customProfile
        ? structuredClone(settings.customProfile)
        : structuredClone(PRESETS[settings.preset] || PRESETS['win-chrome']);
    case 'per-site':
    case 'per-session':
    default: {
      const pool = RANDOM_POOLS[settings.randomPool] || RANDOM_POOLS.desktop;
      return randomProfile(mulberry32(seed), pool, settings.timezoneRegion);
    }
  }
}

// ---- real engine version ---------------------------------------------------
// Spoofing an older Chrome than the engine actually is (e.g. "Chrome/131" on a
// 157 engine) is easy to catch with feature detection, so Chromium-based
// profiles always report the real major/full version of the running engine.
let realVersionCache = null;

async function realChromeVersion() {
  if (realVersionCache) return realVersionCache;
  let major = '';
  let full = '';
  try {
    const ua = navigator.userAgentData;
    if (ua && ua.getHighEntropyValues) {
      const hv = await ua.getHighEntropyValues(['fullVersionList', 'uaFullVersion']);
      const list = hv.fullVersionList || [];
      const chromium = list.find((b) => b.brand === 'Chromium') || list.find((b) => /Chrome/.test(b.brand));
      if (chromium) full = chromium.version;
      if (!full && hv.uaFullVersion) full = hv.uaFullVersion;
    }
  } catch {}
  if (!full) {
    const m = /Chrome\/(\d+)/.exec(navigator.userAgent || '');
    if (m) full = m[1] + '.0.0.0';
  }
  major = (full.split('.')[0] || '').trim();
  if (!/^\d+$/.test(major)) return null;
  realVersionCache = { major, full };
  return realVersionCache;
}

const CHROMIUM_BRANDS = new Set(['Chromium', 'Google Chrome', 'Microsoft Edge', 'Opera', 'Brave']);

function alignVersion(profile, version) {
  if (!profile || !version) return profile;
  const { major, full } = version;
  const fix = (s) => typeof s === 'string'
    ? s.replace(/Chrome\/\d+\.0\.0\.0/g, `Chrome/${major}.0.0.0`).replace(/Edg\/\d+\.0\.0\.0/g, `Edg/${major}.0.0.0`)
    : s;
  profile.userAgent = fix(profile.userAgent);
  profile.appVersion = fix(profile.appVersion);
  const u = profile.uaData;
  if (u && Array.isArray(u.brands)) {
    u.brands = u.brands.map((b) => CHROMIUM_BRANDS.has(b.brand) ? { brand: b.brand, version: major } : b);
    if (u.uaFullVersion) u.uaFullVersion = full;
  }
  return profile;
}

// Resolve the profile AND apply timezone source (IP) + travel-mode overrides.
async function activeProfile(settings, seed) {
  const profile = alignVersion(resolveProfile(settings, seed), await realChromeVersion());
  if (settings.timezoneSource === 'ip' && settings.protections.timezone) {
    const geo = await getGeo(false);
    if (geo && geo.timezone) profile.timezone = geo.timezone;
  }
  // Travel mode overrides timezone + locale to the chosen country (wins over IP).
  if (settings.travelCountry && TRAVEL_COUNTRIES[settings.travelCountry]) {
    const t = TRAVEL_COUNTRIES[settings.travelCountry];
    profile.timezone = t.tz;
    profile.language = t.language;
    profile.languages = t.languages.slice();
  }
  return profile;
}

// ---- declarativeNetRequest header sync -------------------------------------

function buildSecChUa(brands) {
  // "Chromium";v="131", "Not_A Brand";v="24", "Google Chrome";v="131"
  return brands.map((b) => `"${b.brand}";v="${b.version}"`).join(', ');
}

function buildFullVersionList(brands, fullVersion) {
  return brands
    .map((b) => {
      const v = b.brand === 'Not_A Brand' ? `${b.version}.0.0.0` : fullVersion;
      return `"${b.brand}";v="${v}"`;
    })
    .join(', ');
}

async function updateHeaderRules(settings, profile) {
  // We own every dynamic rule in this extension — remove them all, then re-add.
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((r) => r.id);

  const addRules = [];
  const excluded = normalizeDomains(settings.allowlist);

  // --- URL tracking-param cleaner ------------------------------------------
  if (settings.enabled && settings.protections.urlClean) {
    const regex = '[?&](' + TRACKING_PARAMS.join('|') + ')=';
    const cond = { regexFilter: regex, resourceTypes: ['main_frame', 'sub_frame'] };
    if (excluded.length) cond.excludedRequestDomains = excluded;
    addRules.push({
      id: URLCLEAN_RULE_ID, priority: 3,
      action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: TRACKING_PARAMS } } } },
      condition: cond
    });
  }

  // --- Referer stripping on third-party requests ----------------------------
  if (settings.enabled && settings.protections.referer) {
    const cond = { domainType: 'thirdParty', resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'image', 'media', 'font', 'stylesheet', 'other'] };
    if (excluded.length) cond.excludedInitiatorDomains = excluded;
    addRules.push({
      id: REFERER_RULE_ID, priority: 1,
      action: { type: 'modifyHeaders', requestHeaders: [{ header: 'referer', operation: 'remove' }] },
      condition: cond
    });
  }

  // --- block third-party cookies -------------------------------------------
  if (settings.enabled && settings.protections.thirdPartyCookies) {
    const cond = { domainType: 'thirdParty', resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'image', 'media', 'font', 'stylesheet', 'ping', 'other'] };
    if (excluded.length) cond.excludedInitiatorDomains = excluded;
    addRules.push({
      id: TPCOOKIES_RULE_ID, priority: 1,
      action: { type: 'modifyHeaders', requestHeaders: [{ header: 'cookie', operation: 'remove' }], responseHeaders: [{ header: 'set-cookie', operation: 'remove' }] },
      condition: cond
    });
  }

  // --- tracker blocking -----------------------------------------------------
  if (settings.enabled && settings.protections.trackers) {
    const cond = { requestDomains: TRACKER_DOMAINS, resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'image', 'ping', 'media', 'websocket', 'other'] };
    if (excluded.length) cond.excludedInitiatorDomains = excluded; // don't block on allowlisted sites
    addRules.push({ id: TRACKER_RULE_ID, priority: 2, action: { type: 'block' }, condition: cond });
  }

  // --- header rewriting (UA + DNT/GPC) --------------------------------------
  if (settings.enabled && (settings.protections.headers || settings.protections.dnt)) {
    const ua = profile.uaData || {};
    const headers = [];
    if (settings.protections.headers) {
      headers.push({ header: 'user-agent', operation: 'set', value: profile.userAgent });
      headers.push({ header: 'accept-language', operation: 'set', value: `${profile.language},${profile.language.split('-')[0]};q=0.9` });
    }
    if (settings.protections.dnt) {
      headers.push({ header: 'dnt', operation: 'set', value: '1' });
      headers.push({ header: 'sec-gpc', operation: 'set', value: '1' });
    }
    if (settings.protections.headers) {
      if (ua.brands && ua.brands.length) {
        headers.push({ header: 'sec-ch-ua', operation: 'set', value: buildSecChUa(ua.brands) });
        headers.push({ header: 'sec-ch-ua-mobile', operation: 'set', value: ua.mobile ? '?1' : '?0' });
        headers.push({ header: 'sec-ch-ua-platform', operation: 'set', value: `"${ua.platform}"` });
        headers.push({ header: 'sec-ch-ua-platform-version', operation: 'set', value: `"${ua.platformVersion || ''}"` });
        headers.push({ header: 'sec-ch-ua-arch', operation: 'set', value: `"${ua.architecture || ''}"` });
        headers.push({ header: 'sec-ch-ua-bitness', operation: 'set', value: `"${ua.bitness || ''}"` });
        headers.push({ header: 'sec-ch-ua-model', operation: 'set', value: `"${ua.model || ''}"` });
        headers.push({ header: 'sec-ch-ua-full-version', operation: 'set', value: `"${ua.uaFullVersion || ''}"` });
        headers.push({ header: 'sec-ch-ua-full-version-list', operation: 'set', value: buildFullVersionList(ua.brands, ua.uaFullVersion || '') });
      } else {
        // Safari / non-Chromium profiles never send Client Hints — strip them.
        for (const h of ['sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform', 'sec-ch-ua-platform-version',
          'sec-ch-ua-arch', 'sec-ch-ua-bitness', 'sec-ch-ua-model', 'sec-ch-ua-full-version', 'sec-ch-ua-full-version-list']) {
          headers.push({ header: h, operation: 'remove' });
        }
      }
    }

    const condition = {
      urlFilter: '*',
      resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'image', 'stylesheet', 'font', 'media', 'websocket', 'other']
    };
    if (excluded.length) condition.excludedRequestDomains = excluded;

    if (headers.length) {
      addRules.push({
        id: DNR_RULE_BASE,
        priority: 1,
        action: { type: 'modifyHeaders', requestHeaders: headers },
        condition
      });
    }
  }

  // Resilience: the core rules (UA/header spoofing + tracker blocking) must ALWAYS
  // apply. If a newer rule (urlClean/referer) is rejected on some Chromium build,
  // fall back to the core set so nothing silently breaks — and never let this
  // throw up the call chain (which would hang setSettings/rebuild).
  const coreIds = new Set([DNR_RULE_BASE, TRACKER_RULE_ID]);
  const coreRules = addRules.filter((r) => coreIds.has(r.id));
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  } catch (e) {
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: coreRules });
      console.warn('Nébula: extra DNR rules rejected, core rules applied.', e && e.message);
    } catch (e2) {
      try { await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] }); } catch {}
      console.warn('Nébula: DNR update failed.', e2 && e2.message);
    }
  }
}

function normalizeDomains(list) {
  const out = [];
  for (const raw of list || []) {
    let d = String(raw).trim().toLowerCase();
    if (!d) continue;
    d = d.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^\*\./, '');
    if (d) out.push(d);
  }
  return out;
}

// ---- IP-based timezone -----------------------------------------------------
// When enabled, the exposed timezone is made to match the geolocation of the
// user's current IP (their real location, or their VPN/proxy exit) so that
// sites which cross-check "JS timezone vs IP geolocation" see no mismatch.
// This is the only feature that makes a network request, and only when on.

async function getGeo(force) {
  if (!force) {
    const cached = (await chrome.storage.local.get(GEO_KEY))[GEO_KEY];
    if (cached && cached.timezone && Date.now() - cached.ts < GEO_TTL_MS) return cached;
  }
  const endpoints = [
    { url: 'https://ipapi.co/json/', map: (d) => ({ timezone: d.timezone, country: d.country_code || d.country }) },
    { url: 'https://ipwho.is/', map: (d) => (d && d.success === false ? null : { timezone: d.timezone && d.timezone.id, country: d.country_code }) },
    { url: 'https://worldtimeapi.org/api/ip', map: (d) => ({ timezone: d.timezone, country: null }) }
  ];
  for (const e of endpoints) {
    try {
      const res = await fetch(e.url, { cache: 'no-store' });
      if (!res.ok) continue;
      const d = await res.json();
      const m = e.map(d);
      if (m && m.timezone) {
        const geo = { timezone: m.timezone, country: m.country || null, ts: Date.now(), source: e.url };
        await chrome.storage.local.set({ [GEO_KEY]: geo });
        return geo;
      }
    } catch {}
  }
  // Fallback: the browser's own configured timezone usually matches the home IP.
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const geo = { timezone: tz, country: null, ts: Date.now(), source: 'browser', fallback: true };
    await chrome.storage.local.set({ [GEO_KEY]: geo });
    return geo;
  } catch {}
  return null;
}

// ---- publish runtime config for content scripts ----------------------------

async function rebuild() {
  const settings = await getSettings();
  const seed = await getSeed();
  const profile = await activeProfile(settings, seed);

  const config = {
    enabled: settings.enabled,
    mode: settings.mode,
    noise: settings.noise,
    noiseStrategy: settings.noiseStrategy,
    protections: settings.protections,
    webrtcMode: settings.webrtcMode,
    timingPrecisionMs: settings.timingPrecisionMs,
    allowlist: normalizeDomains(settings.allowlist),
    baseSeed: seed,
    profile,
    fpLog: settings.fpLog !== false,
    cookieBanners: settings.cookieBanners !== false,
    cfHelper: settings.cfHelper !== false
  };
  await chrome.storage.local.set({ [CONFIG_KEY]: config });
  await syncBootScript(config);
  await updateHeaderRules(settings, profile);
  updateBadge(settings.enabled);
  await syncRotateAlarm();
  return config;
}

// ---- instant protection (user script) ---------------------------------------
// Content scripts can only read chrome.storage asynchronously, so on their own
// the protections switch on a moment after the page has started running — long
// enough for a fingerprinting script in <head> to read the real values. A user
// script can carry the config inline, so it is available synchronously at
// document_start. Requires "Allow user scripts" for this extension (Chrome 138+:
// extension details page; older Chromium: developer mode). Without it, the
// bridge path below keeps working exactly as before.

function bootCode(config) {
  return `(()=>{try{const c=${JSON.stringify(config)};let h='about';` +
    `try{h=location.hostname||(top&&top.location&&top.location.hostname)||'about'}catch(e){}` +
    `const al=c.allowlist||[];const allowed=al.some(d=>h===d||h.endsWith('.'+d));` +
    `const p=(!c.enabled||allowed)?{enabled:false}:{enabled:true,host:h,noise:c.noise,` +
    `noiseStrategy:c.noiseStrategy,protections:c.protections,webrtcMode:c.webrtcMode,` +
    `timingPrecisionMs:c.timingPrecisionMs,baseSeed:c.baseSeed,profile:c.profile,fpLog:c.fpLog};` +
    `const s=JSON.stringify(p);` +
    `if(window.__nebulaInstalled){window.dispatchEvent(new CustomEvent('nebula:config',{detail:s}))}` +
    `else{Object.defineProperty(window,'__nebulaBoot',{value:s,configurable:true,writable:true,enumerable:false})}` +
    `}catch(e){}})();`;
}

async function syncBootScript(config) {
  let status = 'unsupported';
  try {
    const api = chrome.userScripts;
    if (api && api.register) {
      if (!config) config = (await chrome.storage.local.get(CONFIG_KEY))[CONFIG_KEY];
      if (!config) return 'pending';
      const script = {
        id: BOOT_SCRIPT_ID,
        matches: ['<all_urls>'],
        allFrames: true,
        runAt: 'document_start',
        world: 'MAIN',
        js: [{ code: bootCode(config) }, { file: 'src/content/protect.js' }]
      };
      const existing = await api.getScripts({ ids: [BOOT_SCRIPT_ID] });
      if (existing.length) await api.update([script]);
      else await api.register([script]);
      status = 'active';
    }
  } catch {
    // The API exists but the user has not allowed user scripts yet.
    status = 'needs-permission';
  }
  try { await chrome.storage.local.set({ [BOOT_STATUS_KEY]: status }); } catch {}
  return status;
}

function updateBadge(enabled) {
  // Only the color here; the text is the per-tab tracker count (setBadge).
  try { chrome.action.setBadgeBackgroundColor({ color: enabled ? '#6d5efc' : '#888888' }); } catch {}
}
function setBadge(tabId) {
  try {
    const n = tabTrackers[tabId] || 0;
    chrome.action.setBadgeText({ tabId, text: n ? (n > 999 ? '999+' : String(n)) : '' });
  } catch {}
}

// ---- lifecycle --------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async () => {
  const got = await chrome.storage.local.get(SETTINGS_KEY);
  if (!got[SETTINGS_KEY]) await chrome.storage.local.set({ [SETTINGS_KEY]: DEFAULT_SETTINGS });
  await getSeed();
  await rebuild();
  setupContextMenus();
});

// ---- right-click context menu ----------------------------------------------
function setupContextMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: 'nebula-newid', title: 'Nébula: Nueva identidad', contexts: ['all'] });
      chrome.contextMenus.create({ id: 'nebula-allow', title: 'Nébula: Lista blanca este sitio', contexts: ['all'] });
      chrome.contextMenus.create({ id: 'nebula-panel', title: 'Nébula: Abrir panel', contexts: ['all'] });
    });
  } catch {}
}

try {
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === 'nebula-newid') {
      await regenerateSeed();
    } else if (info.menuItemId === 'nebula-allow' && tab && tab.url) {
      try {
        const host = new URL(tab.url).hostname;
        const parts = host.split('.');
        const base = parts.length <= 2 ? host : parts.slice(-2).join('.');
        const s = await getSettings();
        if (!s.allowlist.includes(base)) await setSettings({ allowlist: [...s.allowlist, base] });
        if (tab.id != null) chrome.tabs.reload(tab.id);
      } catch {}
    } else if (info.menuItemId === 'nebula-panel') {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
    }
  });
} catch {}

chrome.runtime.onStartup.addListener(async () => {
  // The registered user script survives restarts, but make sure it is current.
  syncBootScript();
  // New browser session → fresh seed for per-session mode.
  await regenerateSeed();
  // Refresh IP geolocation (the exit IP may have changed since last run).
  const settings = await getSettings();
  if (settings.timezoneSource === 'ip') { await getGeo(true); await rebuild(); }
  setupContextMenus();
});

// Keyboard shortcuts.
try {
  chrome.commands.onCommand.addListener(async (cmd) => {
    if (cmd === 'new-identity') {
      await regenerateSeed();
    } else if (cmd === 'panic') {
      await setSettings({ enabled: false });
      const settings = await getSettings();
      await clearBrowsingState(settings.cleanData);
    }
  });
} catch {}

// Make sure config exists whenever the worker wakes.
rebuild().catch(() => {});

// ---- messaging --------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
   try {
    switch (msg && msg.type) {
      case 'getState': {
        const settings = await getSettings();
        const seed = await getSeed();
        const profile = await activeProfile(settings, seed);
        const geo = (await chrome.storage.local.get(GEO_KEY))[GEO_KEY] || null;
        // Re-check every time the popup opens: the user may have just allowed user scripts.
        const instant = await syncBootScript();
        sendResponse({ settings, seed, profile, presets: presetList(), geo, instant });
        break;
      }
      case 'refreshGeo': {
        const geo = await getGeo(true);
        await rebuild();
        sendResponse({ ok: true, geo });
        break;
      }
      case 'setSettings': {
        const next = await setSettings(msg.patch || {});
        sendResponse({ ok: true, settings: next });
        break;
      }
      case 'regenerateSeed': {
        const seed = await regenerateSeed();
        sendResponse({ ok: true, seed });
        break;
      }
      case 'newIdentity': {
        // Optionally switch to a chosen device first.
        if (msg.device) await setSettings({ mode: 'blend', preset: msg.device });
        const seed = await regenerateSeed(); // fresh fingerprint (+ rebuild)
        if (msg.timezoneSource === 'ip') await getGeo(true).then(() => rebuild());
        let cleared = false;
        if (msg.clean !== false) {
          const settings = await getSettings();
          cleared = await clearBrowsingState(settings.cleanData);
        }
        const settings = await getSettings();
        const profile = await activeProfile(settings, seed);
        sendResponse({ ok: true, seed, cleared, profile });
        break;
      }
      case 'resetSettings': {
        await chrome.storage.local.set({ [SETTINGS_KEY]: DEFAULT_SETTINGS });
        await rebuild();
        sendResponse({ ok: true, settings: DEFAULT_SETTINGS });
        break;
      }
      case 'aiSuggest': {
        const res = await aiSuggest(msg.host);
        sendResponse(res);
        break;
      }
      case 'getStats': {
        const settings = await getSettings();
        sendResponse({ ok: true, trackers: tabTrackers[msg.tabId] || 0, blocking: !!settings.protections.trackers });
        break;
      }
      case 'getStatsFull': {
        await flushStats();
        const settings = await getSettings();
        const seed = await getSeed();
        const profile = await activeProfile(settings, seed);
        const stats = (await chrome.storage.local.get(STATS_KEY))[STATS_KEY] || { total: 0, days: {}, top: {} };
        const fplog = (await chrome.storage.local.get(FPLOG_KEY))[FPLOG_KEY] || {};
        sendResponse({ ok: true, stats, settings, profile, fplog });
        break;
      }
      case 'fpAttempt': {
        if (msg.host && msg.kind) recordFp(msg.host, msg.kind);
        sendResponse({ ok: true });
        break;
      }
      case 'aiChat': {
        const r = await aiChat(msg.history || []);
        sendResponse(r);
        break;
      }
      case 'allowlistSite': {
        const host = String(msg.host || '');
        const parts = host.split('.');
        const base = parts.length <= 2 ? host : parts.slice(-2).join('.');
        const s = await getSettings();
        if (base && !s.allowlist.includes(base)) await setSettings({ allowlist: [...s.allowlist, base] });
        sendResponse({ ok: true });
        break;
      }
      case 'panic': {
        await setSettings({ enabled: false });
        const settings = await getSettings();
        const cleared = await clearBrowsingState(settings.cleanData);
        sendResponse({ ok: true, cleared });
        break;
      }
      default:
        sendResponse({ ok: false, error: 'unknown message' });
    }
   } catch (err) {
     // Never hang the caller — always respond, even on an unexpected error.
     try { sendResponse({ ok: false, error: String((err && err.message) || err) }); } catch {}
   }
  })();
  return true; // async
});

function presetList() {
  return Object.entries(PRESETS).map(([id, p]) => ({ id, label: p.label }));
}

// ---- optional cloud-AI profile advisor -------------------------------------

function aiSystemPrompt(presets) {
  const list = presets.map((p) => `${p.id} = ${p.label}`).join('; ');
  return [
    'Eres el asesor de perfiles de "Nébula", una extensión de privacidad anti-fingerprinting.',
    'El usuario está en un sitio web y quiere la configuración más PRIVADA y COHERENTE.',
    'Elige UNA recomendación:',
    '- "allowlist": desactivar la extensión en este sitio (ideal para bancos, pagos, gobierno, o sitios donde el usuario inicia sesión con su identidad real, o que se rompen al falsear datos).',
    '- "device": imitar un dispositivo que pase desapercibido Y sea coherente con el sistema/motor REAL del usuario (nunca elijas un SO que contradiga el real; p. ej. no elijas iPhone si el navegador real es Android/Chromium).',
    '- "keep": mantener la protección aleatoria actual (bien para navegación general).',
    'Reglas: SOLO ayudas con privacidad y coherencia interna. NO ayudas a evadir el antifraude, la detección de bots ni la verificación de ningún servicio concreto. Si falsear datos en este sitio es inútil o arriesgado, prefiere "allowlist".',
    `Presets disponibles: ${list}.`,
    'Responde SOLO con un objeto JSON compacto, sin prosa ni markdown:',
    '{"action":"allowlist"|"device"|"keep","preset":"<id del preset o null>","reason":"<una frase corta en español>"}'
  ].join('\n');
}

function parseSuggestion(text) {
  if (!text) return null;
  let t = text.trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const a = t.indexOf('{');
  const b = t.lastIndexOf('}');
  if (a >= 0 && b > a) t = t.slice(a, b + 1);
  try {
    const o = JSON.parse(t);
    if (!o || !['allowlist', 'device', 'keep'].includes(o.action)) return null;
    return { action: o.action, preset: o.preset || null, reason: String(o.reason || '') };
  } catch { return null; }
}

async function aiSuggest(host) {
  const settings = await getSettings();
  const ai = settings.ai || {};
  if (!ai.enabled) return { ok: false, error: 'El asistente IA está desactivado.' };
  const needsKey = ai.provider !== 'pollinations';
  if (needsKey && !ai.apiKey) return { ok: false, error: 'Falta la API key en Ajustes.' };

  const presets = presetList();
  const system = aiSystemPrompt(presets);
  const realUA = (typeof navigator !== 'undefined' && navigator.userAgent) || 'desconocido';
  const userMsg = `Sitio: ${host || 'desconocido'}\nNavegador real del usuario: ${realUA}`;

  // OpenAI-compatible providers (same request/response shape, different endpoint).
  // 'pollinations' needs NO API key (free public endpoint).
  const OPENAI_COMPAT = {
    openai: { url: 'https://api.openai.com/v1/chat/completions', model: 'gpt-4o-mini' },
    groq: { url: 'https://api.groq.com/openai/v1/chat/completions', model: 'llama-3.3-70b-versatile' },
    openrouter: { url: 'https://openrouter.ai/api/v1/chat/completions', model: 'meta-llama/llama-3.3-70b-instruct:free' },
    deepseek: { url: 'https://api.deepseek.com/chat/completions', model: 'deepseek-chat' },
    pollinations: { url: 'https://text.pollinations.ai/openai', model: 'openai', noKey: true }
  };

  async function callOnce() {
    let res, data, text = '';
    if (ai.provider === 'gemini') {
      const model = ai.model || 'gemini-3.8-flash';
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(ai.apiKey)}`;
      res = await fetch(url, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: system }] },
          contents: [{ role: 'user', parts: [{ text: userMsg }] }],
          generationConfig: { maxOutputTokens: 500, temperature: 0.2 }
        })
      });
      data = await res.json().catch(() => ({}));
      if (!res.ok) { const e = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      const parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
      text = (parts || []).map((p) => p.text || '').join('');
    } else if (OPENAI_COMPAT[ai.provider]) {
      const cfg = OPENAI_COMPAT[ai.provider];
      const headers = { 'content-type': 'application/json' };
      if (!cfg.noKey) headers.authorization = 'Bearer ' + ai.apiKey;
      if (ai.provider === 'openrouter') headers['x-title'] = 'Nebula Anti-Fingerprint';
      res = await fetch(cfg.url, {
        method: 'POST', headers,
        body: JSON.stringify({
          model: ai.model || cfg.model,
          max_tokens: 500,
          messages: [{ role: 'system', content: system }, { role: 'user', content: userMsg }]
        })
      });
      const raw = await res.text();
      try { data = JSON.parse(raw); } catch { data = null; }
      if (!res.ok) { const e = new Error((data && data.error && data.error.message) || raw.slice(0, 160) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      // OpenAI shape, or (pollinations fallback) plain text.
      text = (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || (data ? '' : raw);
    } else {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': ai.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify({ model: ai.model || 'claude-opus-5-5', max_tokens: 1024, system, messages: [{ role: 'user', content: userMsg }] })
      });
      data = await res.json().catch(() => ({}));
      if (!res.ok) { const e = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    }
    return text;
  }

  function isTransient(e) {
    const s = e && e.status;
    if ([429, 500, 502, 503, 529].includes(s)) return true;
    return /high demand|overload|try again|temporarily|unavailable|rate.?limit/i.test(String((e && e.message) || ''));
  }

  let text = '', lastErr = null;
  for (let i = 0; i < 3; i++) {
    try { text = await callOnce(); lastErr = null; break; }
    catch (e) { lastErr = e; if (i === 2 || !isTransient(e)) break; await new Promise((r) => setTimeout(r, 1200 * (i + 1))); }
  }
  if (lastErr) {
    let msg = String((lastErr && lastErr.message) || lastErr);
    if (isTransient(lastErr)) msg = 'El servidor de IA está saturado ahora mismo. Intenta de nuevo en un momento. (' + msg + ')';
    return { ok: false, error: msg };
  }
  const suggestion = parseSuggestion(text);
  if (!suggestion) return { ok: false, error: 'La IA no devolvió una sugerencia válida.' };
  return { ok: true, suggestion };
}

// Generic multi-message completion across all providers (used by the chat).
async function aiComplete(ai, system, messages, maxTokens) {
  maxTokens = maxTokens || 700;
  const OPENAI_COMPAT = {
    openai: { url: 'https://api.openai.com/v1/chat/completions', model: 'gpt-4o-mini' },
    groq: { url: 'https://api.groq.com/openai/v1/chat/completions', model: 'llama-3.3-70b-versatile' },
    openrouter: { url: 'https://openrouter.ai/api/v1/chat/completions', model: 'meta-llama/llama-3.3-70b-instruct:free' },
    deepseek: { url: 'https://api.deepseek.com/chat/completions', model: 'deepseek-chat' },
    pollinations: { url: 'https://text.pollinations.ai/openai', model: 'openai', noKey: true }
  };
  async function callOnce() {
    let res, data, text = '';
    if (ai.provider === 'gemini') {
      const model = ai.model || 'gemini-3.8-flash';
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(ai.apiKey)}`;
      const contents = messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ system_instruction: { parts: [{ text: system }] }, contents, generationConfig: { maxOutputTokens: maxTokens, temperature: 0.4 } }) });
      data = await res.json().catch(() => ({}));
      if (!res.ok) { const e = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      const parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
      text = (parts || []).map((p) => p.text || '').join('');
    } else if (OPENAI_COMPAT[ai.provider]) {
      const cfg = OPENAI_COMPAT[ai.provider];
      const headers = { 'content-type': 'application/json' };
      if (!cfg.noKey) headers.authorization = 'Bearer ' + ai.apiKey;
      if (ai.provider === 'openrouter') headers['x-title'] = 'Nebula Anti-Fingerprint';
      res = await fetch(cfg.url, { method: 'POST', headers, body: JSON.stringify({ model: ai.model || cfg.model, max_tokens: maxTokens, messages: [{ role: 'system', content: system }, ...messages] }) });
      const raw = await res.text();
      try { data = JSON.parse(raw); } catch { data = null; }
      if (!res.ok) { const e = new Error((data && data.error && data.error.message) || raw.slice(0, 160) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      text = (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || (data ? '' : raw);
    } else {
      res = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': ai.apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify({ model: ai.model || 'claude-opus-5-5', max_tokens: maxTokens, system, messages }) });
      data = await res.json().catch(() => ({}));
      if (!res.ok) { const e = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); e.status = res.status; throw e; }
      text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    }
    return text;
  }
  const isTransient = (e) => [429, 500, 502, 503, 529].includes(e && e.status) || /high demand|overload|try again|temporarily|unavailable|rate.?limit/i.test(String((e && e.message) || ''));
  let text = '', lastErr = null;
  for (let i = 0; i < 3; i++) {
    try { text = await callOnce(); lastErr = null; break; }
    catch (e) { lastErr = e; if (i === 2 || !isTransient(e)) break; await new Promise((r) => setTimeout(r, 1200 * (i + 1))); }
  }
  if (lastErr) {
    let m = String((lastErr && lastErr.message) || lastErr);
    if (isTransient(lastErr)) m = 'El servidor de IA está saturado. Intenta de nuevo en un momento.';
    return { ok: false, error: m };
  }
  return { ok: true, text: (text || '').trim() };
}

async function aiChat(history) {
  const settings = await getSettings();
  const ai = settings.ai || {};
  if (!ai.enabled) return { ok: false, error: 'Activa el asistente IA en Ajustes.' };
  if (ai.provider !== 'pollinations' && !ai.apiKey) return { ok: false, error: 'Falta la API key en Ajustes.' };
  const system = [
    'Eres el asistente de privacidad de "Nébula", una extensión anti-fingerprinting de código abierto.',
    'Ayudas al usuario a entender el fingerprinting del navegador, los rastreadores, la privacidad web y cómo usar la extensión (perfiles, lista blanca, modo viaje, bloqueo de rastreadores, etc.).',
    'Responde en español, claro y conciso. Sé honesto sobre los límites (una extensión no cambia las capas de red TCP/TLS, no te hace 100% invisible).',
    'NO ayudas a evadir el antifraude, la detección de bots ni la verificación de ningún servicio; NO ayudas con fraude ni actividades ilegales. Si te lo piden, explícalo y redirige a la privacidad legítima.'
  ].join(' ');
  const messages = (history || []).slice(-12).map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 2000) }));
  if (!messages.length) return { ok: false, error: 'Escribe una pregunta.' };
  return aiComplete(ai, system, messages, 700);
}
